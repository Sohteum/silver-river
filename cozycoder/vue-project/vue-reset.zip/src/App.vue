<template>
  app
</template>

<script>
export default {
  name: 'App',
}
</script>
